﻿using HospitalReservationSystem.Entity;
using HospitalReservationSystem.Modals;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalReservationSystem.DAL
{
    class EmployeesHelper
    {
        public static bool EmployeeCUD(Employee employee, EntityState entityState)
        {
            using (var h = new HospitalDbEntities())
            {
                h.Entry(employee).State = entityState;

                if (h.SaveChanges() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public static List<Employee> GetEmployees()
        {
            using (var h = new HospitalDbEntities())
            {
                return h.Employees.ToList();
            }
        }
        public static List<EmployeeModal> GetEmployeeModals()
        {
            List<EmployeeModal> eml = new List<EmployeeModal>();
            using (var h = new HospitalDbEntities())
            {
                var el = h.Employees.ToList();
                foreach (var e in el)
                {
                    EmployeeModal em = new EmployeeModal();
                    em.PersonnelID = e.PersonnelID;
                    em.UserID = e.UserID;
                    em.PName = e.PName;
                    em.PLastname = e.PLastname;
                    em.DepartmentID = e.DepartmentID;
                    em.Department.DName = e.Department.DName;
                    em.PStatus = e.PStatus;
                    eml.Add(em);
                }
                return eml;
            }
        }
        public static bool DeleteEmployee(Employee emp)
        {
            using (var h = new HospitalDbEntities())
            {
                h.Entry(emp).State = EntityState.Modified;
                emp.PStatus = false;

                if (h.SaveChanges() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public static Employee GetByID(int id)
        {
            using (var h = new HospitalDbEntities())
            {
                return h.Employees.Where(x => x.PersonnelID == id).FirstOrDefault();
            }

        }
        public static bool EditEmployee(Employee emp, string name, string lastname, int departmentid)
        {
            using (var h = new HospitalDbEntities())
            {
                h.Entry(emp).State = EntityState.Modified;
                emp.PName = name;
                emp.PLastname = lastname;
                emp.DepartmentID = departmentid;

                if (h.SaveChanges() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public static List<Employee> GetEmployeesByDepartmentID(int id)
        {
            using (var h = new HospitalDbEntities())
            {
                return h.Employees.Where(x => x.DepartmentID == id && x.PStatus==true).ToList();
            }
        }
    }
}
