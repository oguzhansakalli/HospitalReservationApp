﻿using HospitalReservationSystem.Entity;
using HospitalReservationSystem.Modals;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalReservationSystem.DAL
{
    class AppointmentsHelper
    {
        public static List<AppointmentModal> GetAppointmentModals()
        {
            List<AppointmentModal> aml = new List<AppointmentModal>();
            using (var h = new HospitalDbEntities())
            {
                var al = h.Appointments.OrderBy(x => x.Date).ThenBy(x => x.Date).ThenBy(x=>x.SessionID).ToList();
                foreach (var a in al)
                {
                    AppointmentModal am = new AppointmentModal();
                    am.AppointmentID = a.AppointmentID;
                    am.PersonnelID = a.PersonnelID;
                    am.EmployeeModal.PName = a.Employee.PName;
                    am.EmployeeModal.PLastname = a.Employee.PLastname;
                    am.PatientID = a.PatientID;
                    am.PatientInformation.Name = a.PatientInformation.Name;
                    am.PatientInformation.Lastname = a.PatientInformation.Lastname;
                    am.PatientInformation.TCNo = a.PatientInformation.TCNo;
                    am.Session.SessionID = a.SessionID;
                    am.Session.STime = a.Session.STime;
                    am.EmployeeModal.Department.DName = a.Employee.Department.DName;
                    am.Date = a.Date;
                    am.AStatus = a.AStatus;
                    aml.Add(am);
                }
                return aml;
            }
        }
        public static (AppointmentModal, bool) GetAppointmentByTC(string TCNo)
        {
            using (var h = new HospitalDbEntities())
            {

                var a = h.Appointments.Where(x => x.PatientInformation.TCNo == TCNo).FirstOrDefault();
                if (a != null)
                {
                    AppointmentModal am = new AppointmentModal();
                    am.AppointmentID = a.AppointmentID;
                    am.PersonnelID = a.PersonnelID;
                    am.EmployeeModal.PName = a.Employee.PName;
                    am.EmployeeModal.PLastname = a.Employee.PLastname;
                    am.PatientID = a.PatientID;
                    am.PatientInformation.Name = a.PatientInformation.Name;
                    am.PatientInformation.Lastname = a.PatientInformation.Lastname;
                    am.PatientInformation.TCNo = a.PatientInformation.TCNo;
                    am.Session.SessionID = a.SessionID;
                    am.Session.STime = a.Session.STime;
                    am.EmployeeModal.Department.DName = a.Employee.Department.DName;
                    am.Date = a.Date;
                    am.AStatus = a.AStatus;
                    return (am, true);
                }
                else
                {
                    return (null, false);
                }
            }
        }
        public static Appointment GetAppointmentByID(int appointmentID)
        {
            using (var h = new HospitalDbEntities())
            {
                return h.Appointments.Where(x => x.AppointmentID == appointmentID).FirstOrDefault();
            }
        }
        public static bool DeleteAppointment(Appointment a)
        {
            using (var h = new HospitalDbEntities())
            {
                h.Entry(a).State = EntityState.Modified;
                a.AStatus = false;
                if (h.SaveChanges() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public static bool GetSessionStatus( int personnelID, DateTime date, int sessionID)
        {
            using (var h = new HospitalDbEntities())
            {
                var selectedSession = h.Appointments.Where(x => x.PersonnelID == personnelID && x.Date == date && x.SessionID==sessionID).FirstOrDefault();
                if (selectedSession != null)
                {
                    if (selectedSession.AStatus)
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
                else
                {
                    return true;
                }
            }
        }
        public static bool AddAppointment(Appointment a)
        {
            using (var h = new HospitalDbEntities())
            {
                h.Entry(a).State = EntityState.Added;
                if (h.SaveChanges()>0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }

}
