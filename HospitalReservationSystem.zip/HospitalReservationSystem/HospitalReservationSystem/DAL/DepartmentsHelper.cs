﻿using HospitalReservationSystem.Entity;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalReservationSystem.DAL
{
    class DepartmentsHelper
    {
        public static List<Department> GetDepartments()
        {
            using (var h = new HospitalDbEntities())
            {
                return h.Departments.ToList();
            }
        }
        public static List<Department> GetActiveDepartments()
        {
            using (var h = new HospitalDbEntities())
            {
                return h.Departments.Where(x => x.DStatus == true && !x.DName.Equals("Resepsiyon")).ToList();
            }
        }
        public static List<Department> GetDeletedDepartments()
        {
            using (var h = new HospitalDbEntities())
            {
                return h.Departments.Where(x => x.DStatus == false).ToList();
            }
        }
        public static bool ChangeDName(Department department, string name)
        {
            using (var h = new HospitalDbEntities())
            {
                h.Entry(department).State = EntityState.Modified;
                department.DName = name;
                if (h.SaveChanges() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public static bool AddDepartment(Department department)
        {
            using (var h = new HospitalDbEntities())
            {
                h.Entry(department).State = EntityState.Added;
                if (h.SaveChanges() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public static bool DeleteDepartment(Department department)
        {
            using (var h = new HospitalDbEntities())
            {
                h.Entry(department).State = EntityState.Modified;
                department.DStatus = false;
                if (h.SaveChanges() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public static Department GetByID(int id)
        {
            using (var h = new HospitalDbEntities())
            {
                return h.Departments.Where(x => x.DepartmentID == id).FirstOrDefault();
            }
        }
        
    }
}
