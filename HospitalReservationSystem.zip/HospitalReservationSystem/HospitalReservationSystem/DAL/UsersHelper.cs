﻿using HospitalReservationSystem.Entity;
using HospitalReservationSystem.Modals;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalReservationSystem.DAL
{
    class UsersHelper
    {
        public static User ActiveUser;

        public static List<User> GetUsers()
        {
            using (var h = new HospitalDbEntities())
            {
                return h.Users.ToList();
            }
        }
        public static SaveModal Login(string Username, string Password,int UType)
        {
            var SaveModal = new SaveModal();

            using (var h = new HospitalDbEntities())
            {
                var user = h.Users.Where(x => x.Username.ToLower().Equals(Username.ToLower()) && x.Password == Password && x.UStatus == true && x.UType==UType).FirstOrDefault();

                if (user != null)
                {
                    SaveModal.message = "Hoşgeldiniz";
                    SaveModal.isSuccessful = true;

                    ActiveUser = user;
                }
                else
                {
                    SaveModal.message = "Girdiğiniz bilgileri tekrar kontrol edin.";
                    SaveModal.isSuccessful = false;
                }
            }
            return SaveModal;
        }
        public static bool Logout()
        {
            ActiveUser = null;
            return ActiveUser == null;
        }
        public static bool UserCUD(User user, EntityState entityState)
        {
            using (var h = new HospitalDbEntities())
            {
                h.Entry(user).State = entityState;

                if (h.SaveChanges()>0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public static List<User> GetActiveUsers()
        {
            using (var h = new HospitalDbEntities())
            {
                return h.Users.Where(x=>x.UStatus==true).ToList();
            }
        }

    }
}
