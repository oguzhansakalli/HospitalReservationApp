﻿using HospitalReservationSystem.Entity;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalReservationSystem.DAL
{
    class PatientsHelper
    {
        public static List<PatientInformation> GetPatientInformations()
        {
            using (var h = new HospitalDbEntities())
            {
                return h.PatientInformations.ToList();
            }
        }
        public static bool AddPatientInfo(PatientInformation pi)
        {
            using (var h = new HospitalDbEntities())
            {
                h.Entry(pi).State = EntityState.Added;
                if (h.SaveChanges() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public static bool UpdatePatientInfo(PatientInformation pi)
        {
            using (var h = new HospitalDbEntities())
            {
                h.Entry(pi).State = EntityState.Modified;
                if (h.SaveChanges() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public static (PatientInformation,bool) GetPatientByTC(string TCNo)
        {
            using (var h = new HospitalDbEntities())
            {
                
                var sP = h.PatientInformations.Where(x => x.TCNo == TCNo).FirstOrDefault();
                if (sP != null)
                {
                    return (sP,true);
                }
                else
                {
                    return (null, false);
                }
            }
        }
        public static bool EditPatientInfo(PatientInformation pi, string name, string lastname, bool gender, string phone, string address)
        {
            using (var h = new HospitalDbEntities())
            {
                h.Entry(pi).State = EntityState.Modified;
                pi.Name = name;
                pi.Lastname = lastname;
                pi.Gender = gender;
                pi.Phone = phone;
                pi.Address = address;

                if (h.SaveChanges() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public static PatientInformation GetByID(int id)
        {
            using (var h = new HospitalDbEntities())
            {
                return h.PatientInformations.Where(x => x.PatientID == id).FirstOrDefault();
            }
        }
        public static bool CheckTC(string TCNo)
        {
            bool isOK = true;
            using (var h = new HospitalDbEntities())
            {
                foreach (var item in h.PatientInformations.ToList())
                {
                    if (item.TCNo==TCNo)
                    {
                        isOK = false;
                    }                    
                }                
            }
            return isOK;
        }
    }
}
