﻿using HospitalReservationSystem.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalReservationSystem.DAL
{
    class SessionHelper
    {
        public static Session GetSessionByID(int id)
        {
            using (var h = new HospitalDbEntities())
            {
                return h.Sessions.Where(x => x.SessionID == id).FirstOrDefault();
            }
        }
        public static Session GetSessionIDByName(string name)
        {
            using (var h = new HospitalDbEntities())
            {
                return h.Sessions.Where(x => x.STime == name).FirstOrDefault();
            }
        }
    }
}
