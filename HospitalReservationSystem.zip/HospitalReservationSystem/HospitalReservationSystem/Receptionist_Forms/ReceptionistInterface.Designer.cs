﻿namespace HospitalReservationSystem.Receptionist_Forms
{
    partial class ReceptionistInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReceptionistInterface));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnPatients = new System.Windows.Forms.ToolStripDropDownButton();
            this.kayıtlıHastalarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yeniHastaKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnAppointments = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnExit = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.Purple;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 271);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(524, 25);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.BackColor = System.Drawing.Color.DarkMagenta;
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(77, 20);
            this.toolStripStatusLabel1.Text = "Status : ";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.BackColor = System.Drawing.Color.DarkMagenta;
            this.toolStripStatusLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.toolStripStatusLabel2.ForeColor = System.Drawing.Color.Black;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(75, 20);
            this.toolStripStatusLabel2.Text = "Kullanici";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(64, 64);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnPatients,
            this.toolStripSeparator1,
            this.btnAppointments,
            this.toolStripSeparator2,
            this.btnExit});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(524, 71);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnPatients
            // 
            this.btnPatients.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kayıtlıHastalarToolStripMenuItem,
            this.yeniHastaKaydıToolStripMenuItem});
            this.btnPatients.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnPatients.Image = ((System.Drawing.Image)(resources.GetObject("btnPatients.Image")));
            this.btnPatients.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPatients.Name = "btnPatients";
            this.btnPatients.Size = new System.Drawing.Size(144, 68);
            this.btnPatients.Text = "Hastalar";
            // 
            // kayıtlıHastalarToolStripMenuItem
            // 
            this.kayıtlıHastalarToolStripMenuItem.Name = "kayıtlıHastalarToolStripMenuItem";
            this.kayıtlıHastalarToolStripMenuItem.Size = new System.Drawing.Size(194, 24);
            this.kayıtlıHastalarToolStripMenuItem.Text = "Kayıtlı Hastalar";
            this.kayıtlıHastalarToolStripMenuItem.Click += new System.EventHandler(this.kayıtlıHastalarToolStripMenuItem_Click);
            // 
            // yeniHastaKaydıToolStripMenuItem
            // 
            this.yeniHastaKaydıToolStripMenuItem.Name = "yeniHastaKaydıToolStripMenuItem";
            this.yeniHastaKaydıToolStripMenuItem.Size = new System.Drawing.Size(194, 24);
            this.yeniHastaKaydıToolStripMenuItem.Text = "Yeni Hasta Kaydı";
            this.yeniHastaKaydıToolStripMenuItem.Click += new System.EventHandler(this.yeniHastaKaydıToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 71);
            // 
            // btnAppointments
            // 
            this.btnAppointments.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnAppointments.Image = ((System.Drawing.Image)(resources.GetObject("btnAppointments.Image")));
            this.btnAppointments.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAppointments.Name = "btnAppointments";
            this.btnAppointments.Size = new System.Drawing.Size(156, 68);
            this.btnAppointments.Text = "Randevular";
            this.btnAppointments.Click += new System.EventHandler(this.btnAppointments_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 71);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnExit.Image = ((System.Drawing.Image)(resources.GetObject("btnExit.Image")));
            this.btnExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(138, 68);
            this.btnExit.Text = "Çıkış Yap";
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // ReceptionistInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(524, 296);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Name = "ReceptionistInterface";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Resepsiyonist Paneli";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ReceptionistInterface_FormClosing);
            this.Load += new System.EventHandler(this.ReceptionistInterface_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton btnPatients;
        private System.Windows.Forms.ToolStripMenuItem kayıtlıHastalarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yeniHastaKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton btnExit;
        private System.Windows.Forms.ToolStripButton btnAppointments;
    }
}