﻿using HospitalReservationSystem.DAL;
using HospitalReservationSystem.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalReservationSystem.Receptionist_Forms
{
    public partial class NewAppointment : Form
    {
        private int _patientID;
        public NewAppointment(int PatientID)
        {
            InitializeComponent();
            _patientID = PatientID;
        }
        private void LoadDepartments()
        {
            var deparmentlist = DepartmentsHelper.GetActiveDepartments();
            cmbDepartments.ValueMember = "DepartmentID";
            cmbDepartments.DisplayMember = "DName";
            cmbDepartments.DataSource = deparmentlist;
        }
        private void NewAppointment_Load(object sender, EventArgs e)
        {
            LoadDepartments();
            dtpDate.MinDate = DateTime.Today.AddDays(1);
            txtPatient.Text = _patientID.ToString();
            txtPatient.Enabled = false;
        }

        private void cmbDepartments_SelectedIndexChanged(object sender, EventArgs e)
        {
            var elist = EmployeesHelper.GetEmployeesByDepartmentID(Convert.ToInt32(cmbDepartments.SelectedValue));
            cmbDoctors.ValueMember = "PersonnelID";
            cmbDoctors.DisplayMember = "PName";
            cmbDoctors.DataSource = elist;
        }

        private void btnShowSessions_Click(object sender, EventArgs e)
        {
            if (cmbDoctors.SelectedIndex == -1)
            {
                MessageBox.Show("Lütfen bölüm seçiniz.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                flpButtons.Controls.Clear();
                for (int i = 1; i <= 7; i++)
                {
                    Button button = new Button();
                    button.SetBounds(0, 0, 250, 50);
                    var s = SessionHelper.GetSessionByID(i);
                    button.Text = s.STime;
                    var isOK = AppointmentsHelper.GetSessionStatus(Convert.ToInt32(cmbDoctors.SelectedValue), Convert.ToDateTime(dtpDate.Value), i);
                    if (isOK)
                    {
                        button.BackColor = Color.Green;
                    }
                    else
                    {
                        button.BackColor = Color.Red;
                        button.Enabled = false;
                    }
                    button.Click += new EventHandler(button_Click);
                    flpButtons.Controls.Add(button);
                }
            }
        }
        protected void button_Click(object sender, EventArgs e)
        {
            Button button = sender as Button;
            var selectedSession = SessionHelper.GetSessionIDByName(button.Text);
            Appointment newa = new Appointment();
            newa.PatientID = _patientID;
            newa.PersonnelID = Convert.ToInt32(cmbDoctors.SelectedValue);
            newa.SessionID = selectedSession.SessionID;
            newa.Date = Convert.ToDateTime(dtpDate.Value);
            newa.AStatus = true;
            var isSuccessful = AppointmentsHelper.AddAppointment(newa);
            if (isSuccessful)
            {
                MessageBox.Show("Randevu başarıyla alındı.", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show("Randevu alımı başarısız.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }
    }
}
