﻿using HospitalReservationSystem.DAL;
using HospitalReservationSystem.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalReservationSystem.Receptionist_Forms
{
    public partial class UpdatePatientInfo : Form
    {
        private PatientInformation _p;
        public UpdatePatientInfo(PatientInformation p)
        {
            InitializeComponent();
            _p = p;
        }

        private void UpdatePatientInfo_Load(object sender, EventArgs e)
        {
            txtNewName.Text = _p.Name;
            txtNewLastname.Text = _p.Lastname;
            if (_p.Gender)
            {
                cmbNewGender.SelectedIndex = 0;
            }
            else
            {
                cmbNewGender.SelectedIndex = 1;
            }
            txtNewPhone.Text = _p.Phone;
            txtNewAddress.Text = _p.Address;
        }

        private void btnUpdatePatient_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNewName.Text) && !string.IsNullOrEmpty(txtNewLastname.Text) && !string.IsNullOrEmpty(txtNewPhone.Text) && !string.IsNullOrEmpty(txtNewAddress.Text))
            {
                var gender = true;
                if (cmbNewGender.SelectedIndex == 0)
                {
                    gender = true;
                }
                else
                {
                    gender = false;
                }
                var isSuccessful = PatientsHelper.EditPatientInfo(_p, txtNewName.Text.Trim(), txtNewLastname.Text.Trim(), gender, txtNewPhone.Text, txtNewAddress.Text.Trim()) ;
                if (isSuccessful)
                {
                    MessageBox.Show("Hasta bilgisi başarıyla güncellendi.", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Hasta bilgisi güncelleme işlemi bir hatayla karşılaştı.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Lütfen tüm bilgileri doldurun.", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
