﻿
using HospitalReservationSystem.Admin_Forms;
using HospitalReservationSystem.DAL;
using HospitalReservationSystem.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalReservationSystem.Receptionist_Forms
{
    public partial class ReceptionistInterface : Form
    {
        private User _activeUser;
        public ReceptionistInterface()
        {
            InitializeComponent();
        }

        private void kayıtlıHastalarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PatientsPanel pp = new PatientsPanel();
            pp.Show();
        }

        private void ReceptionistInterface_Load(object sender, EventArgs e)
        {
           _activeUser = UsersHelper.ActiveUser;
           toolStripStatusLabel2.Text = _activeUser.Username;
        }

        private void ReceptionistInterface_FormClosing(object sender, FormClosingEventArgs e)
        {
            Login l = new Login();
            l.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            var isSuccessful = UsersHelper.Logout();
            if (isSuccessful)
            {
                Close();
            }
        }

        private void yeniHastaKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewPatient np = new NewPatient();
            np.Show();
        }        

        private void btnAppointments_Click(object sender, EventArgs e)
        {
            AppoinmentPanel ap = new AppoinmentPanel();
            ap.Show();
        }
    }
}
