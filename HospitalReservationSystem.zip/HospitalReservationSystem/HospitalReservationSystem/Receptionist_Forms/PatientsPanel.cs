﻿using HospitalReservationSystem.DAL;
using HospitalReservationSystem.Receptionist_Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalReservationSystem.Admin_Forms
{
    public partial class PatientsPanel : Form
    {
        public PatientsPanel()
        {
            InitializeComponent();
        }

        private void PatientsPanel_Load(object sender, EventArgs e)
        {
            LoadPatientInformations();
        }
        private void LoadPatientInformations()
        {
            dgvPatients.Rows.Clear();
            var pil = PatientsHelper.GetPatientInformations();
            foreach (var pi in pil)
            {
                int satir = dgvPatients.Rows.Add();
                dgvPatients.Rows[satir].Cells[0].Value = pi.PatientID;
                dgvPatients.Rows[satir].Cells[1].Value = pi.Name;
                dgvPatients.Rows[satir].Cells[2].Value = pi.Lastname;
                dgvPatients.Rows[satir].Cells[3].Value = pi.TCNo;
                dgvPatients.Rows[satir].Cells[4].Value = SetGender(pi.Gender);
                dgvPatients.Rows[satir].Cells[5].Value = (DateTime.Now.Year - pi.Birthdate.Year);
                dgvPatients.Rows[satir].Cells[6].Value = pi.Phone;
                dgvPatients.Rows[satir].Cells[7].Value = pi.Address;
            }
        }
        private string SetGender(bool status)
        {
            if (status)
            {
                return "Kadın";
            }
            else if (!status)
            {
                return "Erkek";
            }
            else
            {
                return "Hatalı veri";
            }
        }
        private void CheckTCNo(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            NewPatient np = new NewPatient();
            np.Show();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtTCNoSearch.Text.Length != 11)
            {
                MessageBox.Show("Tc kimlik numarası eksik veya yanlış girildi.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                var searchedPatient = PatientsHelper.GetPatientByTC(txtTCNoSearch.Text);
                if (searchedPatient.Item2)
                {
                    dgvPatients.Rows.Clear();
                    int row = dgvPatients.Rows.Add();
                    dgvPatients.Rows[row].Cells[0].Value = searchedPatient.Item1.PatientID;
                    dgvPatients.Rows[row].Cells[1].Value = searchedPatient.Item1.Name;
                    dgvPatients.Rows[row].Cells[2].Value = searchedPatient.Item1.Lastname;
                    dgvPatients.Rows[row].Cells[3].Value = searchedPatient.Item1.TCNo;
                    dgvPatients.Rows[row].Cells[4].Value = SetGender(searchedPatient.Item1.Gender);
                    dgvPatients.Rows[row].Cells[5].Value = (DateTime.Now.Year - searchedPatient.Item1.Birthdate.Year);
                    dgvPatients.Rows[row].Cells[6].Value = searchedPatient.Item1.Phone;
                    dgvPatients.Rows[row].Cells[7].Value = searchedPatient.Item1.Address;
                    txtTCNoSearch.Clear();
                }
                else
                {
                    MessageBox.Show("Bu kimlik numarasıyla kayıtlı bir hasta bulunamadı.", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnRenewList_Click(object sender, EventArgs e)
        {
            LoadPatientInformations();
            txtTCNoSearch.Clear();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            var row = dgvPatients.CurrentRow.Index;
            var index = dgvPatients.Rows[row].Cells[0].Value;
            var pi = PatientsHelper.GetByID(Convert.ToInt32(index));
            UpdatePatientInfo upi = new UpdatePatientInfo(pi);
            upi.Show();
        }

        private void btnNewAppointment_Click(object sender, EventArgs e)
        {
            var row = dgvPatients.CurrentRow.Index;
            var index = dgvPatients.Rows[row].Cells[0].Value;
            NewAppointment na = new NewAppointment(Convert.ToInt32(index));
            na.Show();
        }

        private void btnReturnMenu_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
