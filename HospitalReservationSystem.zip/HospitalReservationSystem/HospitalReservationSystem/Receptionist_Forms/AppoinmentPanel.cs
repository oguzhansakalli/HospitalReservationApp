﻿using HospitalReservationSystem.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalReservationSystem.Receptionist_Forms
{
    public partial class AppoinmentPanel : Form
    {
        public AppoinmentPanel()
        {
            InitializeComponent();
        }

        private void AppoinmentPanel_Load(object sender, EventArgs e)
        {
            LoadAppointmentModals(true);
        }
        private void LoadAppointmentModals(bool status)
        {
            dgvAppointments.Rows.Clear();
            var aml = AppointmentsHelper.GetAppointmentModals();
            foreach (var am in aml)
            {
                if (am.AStatus == status)
                {
                    int satir = dgvAppointments.Rows.Add();
                    dgvAppointments.Rows[satir].Cells[0].Value = am.AppointmentID;
                    dgvAppointments.Rows[satir].Cells[1].Value = am.PatientInformation.TCNo;
                    dgvAppointments.Rows[satir].Cells[2].Value = am.PatientInformation.Name + " " + am.PatientInformation.Lastname;
                    dgvAppointments.Rows[satir].Cells[3].Value = am.EmployeeModal.PName + " " + am.EmployeeModal.PLastname;
                    dgvAppointments.Rows[satir].Cells[4].Value = am.EmployeeModal.Department.DName;
                    dgvAppointments.Rows[satir].Cells[5].Value = am.Date.ToShortDateString();
                    dgvAppointments.Rows[satir].Cells[6].Value = am.Session.STime;
                }
            }
        }

        private void btnSearchAppointment_Click(object sender, EventArgs e)
        {
            if (txtSearchTC.Text.Length == 11)
            {
                var searchedAppointment = AppointmentsHelper.GetAppointmentByTC(txtSearchTC.Text);
                if (searchedAppointment.Item2)
                {
                    dgvAppointments.Rows.Clear();
                    int satir = dgvAppointments.Rows.Add();
                    dgvAppointments.Rows[satir].Cells[0].Value = searchedAppointment.Item1.AppointmentID;
                    dgvAppointments.Rows[satir].Cells[1].Value = searchedAppointment.Item1.PatientInformation.TCNo;
                    dgvAppointments.Rows[satir].Cells[2].Value = searchedAppointment.Item1.PatientInformation.Name + " " + searchedAppointment.Item1.PatientInformation.Lastname;
                    dgvAppointments.Rows[satir].Cells[3].Value = searchedAppointment.Item1.EmployeeModal.PName + " " + searchedAppointment.Item1.EmployeeModal.PLastname;
                    dgvAppointments.Rows[satir].Cells[4].Value = searchedAppointment.Item1.EmployeeModal.Department.DName;
                    dgvAppointments.Rows[satir].Cells[5].Value = searchedAppointment.Item1.Date.ToShortDateString();
                    dgvAppointments.Rows[satir].Cells[6].Value = searchedAppointment.Item1.Session.STime;
                    txtSearchTC.Clear();
                }
                else
                {
                    MessageBox.Show("Bu kimlik numarasıyla kayıtlı bir hasta bulunamadı.", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Hatalı Tc kimlik numarası girdiniz.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void CheckTCNo(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnDeleteAppointment_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Randevuyu iptal etmekte emin misiniz?(Bu işlem geri alınamaz.)", "UYARI", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dialogResult == DialogResult.Yes)
            {
                var row = dgvAppointments.CurrentRow.Index;
                var index = dgvAppointments.Rows[row].Cells[0].Value;
                var selectedAppointment = AppointmentsHelper.GetAppointmentByID(Convert.ToInt32(index));

                var isSuccessful = AppointmentsHelper.DeleteAppointment(selectedAppointment);
                if (isSuccessful)
                {
                    MessageBox.Show("Kullanıcı başarıyla silindi.", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadAppointmentModals(true);
                }
                else
                {
                    MessageBox.Show("Kullanıcı silme başarısız.", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                
            }
            
        }
    }
}
