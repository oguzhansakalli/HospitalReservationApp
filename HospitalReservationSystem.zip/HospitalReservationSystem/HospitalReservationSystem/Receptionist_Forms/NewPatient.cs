﻿using HospitalReservationSystem.DAL;
using HospitalReservationSystem.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalReservationSystem.Receptionist_Forms
{
    public partial class NewPatient : Form
    {
        public NewPatient()
        {
            InitializeComponent();
        }
        private void IsLetter(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void IsLastname(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void CheckTCNo(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnAddPatient_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtName.Text) && !string.IsNullOrEmpty(txtLastname.Text) && !string.IsNullOrEmpty(txtPhone.Text) && !string.IsNullOrEmpty(txtAddress.Text))
            {
                
                if (PatientsHelper.CheckTC(txtTCNo.Text))
                {
                    PatientInformation pi = new PatientInformation();
                    pi.Name = txtName.Text.Trim();
                    pi.Lastname = txtLastname.Text;
                    pi.TCNo = txtTCNo.Text;
                    if (cmbGender.SelectedIndex == 0)
                    {
                        pi.Gender = true;
                    }
                    else
                    {
                        pi.Gender = false;
                    }
                    pi.Birthdate = Convert.ToDateTime(dtpBirthdate.Value);
                    pi.Phone = txtPhone.Text;
                    pi.Address = txtAddress.Text;
                    var isSuccessful = PatientsHelper.AddPatientInfo(pi);

                    if (isSuccessful)
                    {
                        MessageBox.Show("Yeni hasta bilgisi başarıyla sisteme eklendi.", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Hasta bilgisi ekleme başarısız.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }
                else
                {
                    MessageBox.Show("Sistemde bu TC kimliği kullanan mevcut bir hasta var.", "HATA", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                
            }
            else
            {
                MessageBox.Show("Eksik bilgi girdiniz.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
