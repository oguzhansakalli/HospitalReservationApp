﻿using HospitalReservationSystem.Admin_Forms;
using HospitalReservationSystem.DAL;
using HospitalReservationSystem.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalReservationSystem
{
    public partial class EmployeesPanel : Form
    {
        public EmployeesPanel()
        {
            InitializeComponent();
        }
        private void LoadEmployees(bool status)
        {
            dgvEmployees.Rows.Clear();
            var employeemodallist = EmployeesHelper.GetEmployeeModals();
            foreach (var employee in employeemodallist)
            {
                if (employee.PStatus == status)
                {
                    int satir = dgvEmployees.Rows.Add();
                    dgvEmployees.Rows[satir].Cells[0].Value = employee.PersonnelID;
                    dgvEmployees.Rows[satir].Cells[1].Value = employee.UserID;
                    dgvEmployees.Rows[satir].Cells[2].Value = employee.PName;
                    dgvEmployees.Rows[satir].Cells[3].Value = employee.PLastname;
                    dgvEmployees.Rows[satir].Cells[4].Value = employee.Department.DName;
                }
            }
        }
        private void btnUpdateEmployeesList_Click(object sender, EventArgs e)
        {
            LoadEmployees(true);
        }

        private void EmployeesPanel_Load(object sender, EventArgs e)
        {
            LoadEmployees(true);
        }

        private void btnDeletedEmployees_Click(object sender, EventArgs e)
        {
            LoadEmployees(false);
        }

        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
            AddEmployee ae = new AddEmployee();
            ae.Show();
        }

        private void btnDeleteEmployee_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Personeli silmekte emin misiniz?(Bu işlem geri alınamaz.)", "UYARI", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dialogResult == DialogResult.Yes)
            {
                var row = dgvEmployees.CurrentRow.Index;
                var index = dgvEmployees.Rows[row].Cells[0].Value;
                var selectedEmployee = EmployeesHelper.GetByID(Convert.ToInt32(index));

                var isSuccessful = EmployeesHelper.DeleteEmployee(selectedEmployee);
                if (isSuccessful)
                {
                    MessageBox.Show("Personel başarıyla silindi.", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadEmployees(true);
                }
                else
                {
                    MessageBox.Show("Personel silme başarısız.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        private void btnEditEmployee_Click(object sender, EventArgs e)
        {
            var row = dgvEmployees.CurrentRow.Index;
            var index = dgvEmployees.Rows[row].Cells[0].Value;
            var emp = EmployeesHelper.GetByID(Convert.ToInt32(index));
            var selectedDepartment = dgvEmployees.Rows[row].Cells[4].Value;
            UpdateEmployee ue = new UpdateEmployee(emp, selectedDepartment.ToString());
            ue.Show();
        }
    }
}
