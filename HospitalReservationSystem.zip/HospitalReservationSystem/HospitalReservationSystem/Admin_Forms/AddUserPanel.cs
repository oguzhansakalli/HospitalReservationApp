﻿using HospitalReservationSystem.DAL;
using HospitalReservationSystem.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalReservationSystem
{
    public partial class AddUserPanel : Form
    {
        bool durumUser = false;
        public AddUserPanel()
        {
            InitializeComponent();
        }

        private void AddUserPanel_Load(object sender, EventArgs e)
        {
            cmbNewUType.SelectedIndex = -1;
        }

        private void btnNewUser_Click(object sender, EventArgs e)
        {
            if (txtNewUsername.Text != "" && txtNewPassword.Text != "" && cmbNewUType.SelectedIndex != -1)
            {
                User u = new User();
                u.Username = txtNewUsername.Text;
                u.Password = txtNewPassword.Text;
                u.UType = cmbNewUType.SelectedIndex;
                u.UStatus = true;
                var userlist = UsersHelper.GetUsers();

                foreach (var user in userlist)
                {
                    if (user.Username.Equals(u.Username))
                    {
                        durumUser = true;
                        break;
                    }
                    else
                    {
                        durumUser = false;
                    }
                }

                if (durumUser)
                {
                    MessageBox.Show("Kullanıcı adı mevcut. Lütfen başka bir kullanıcı adı deneyin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    var isSuccessful = UsersHelper.UserCUD(u, EntityState.Added);

                    if (isSuccessful)
                    {
                        MessageBox.Show("Yeni kullanıcı başarıyla sisteme eklendi.", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Kullanıcı ekleme başarısız.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }
            }
            else
            {
                MessageBox.Show("Kullanıcı adı ve şifre boş girilemez.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
