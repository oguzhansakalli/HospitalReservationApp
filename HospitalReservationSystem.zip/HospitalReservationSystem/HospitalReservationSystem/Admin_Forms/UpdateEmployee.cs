﻿using HospitalReservationSystem.DAL;
using HospitalReservationSystem.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalReservationSystem.Admin_Forms
{
    public partial class UpdateEmployee : Form
    {
        private Employee emp;
        private string selectedDepartment;
        private string _userID;
        public UpdateEmployee(Employee emp, string DName)
        {
            InitializeComponent();
            this.emp = emp;
            selectedDepartment = DName;
        }

        private void UpdateEmployee_Load(object sender, EventArgs e)
        {

            LoadDepartments();
            txtEmpName.Text = emp.PName;
            txtEmpLname.Text = emp.PLastname;
            cmbDepartments.SelectedIndex = cmbDepartments.FindString(selectedDepartment);

        }

        private void LoadDepartments()
        {
            var deparmentlist = DepartmentsHelper.GetActiveDepartments();
            cmbDepartments.ValueMember = "DepartmentID";
            cmbDepartments.DisplayMember = "DName";
            cmbDepartments.DataSource = deparmentlist;
        }

        private void btnUpdateEmployee_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtEmpName.Text) && !string.IsNullOrEmpty(txtEmpLname.Text))
            {
                var isSuccessful = EmployeesHelper.EditEmployee(emp, txtEmpName.Text, txtEmpLname.Text, Convert.ToInt32(cmbDepartments.SelectedValue));
                if (isSuccessful)
                {
                    MessageBox.Show("Personel bilgileri başarıyla güncellendi.", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Personel bilgileri güncelleme işlemi bir hatayla karşılaştı.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Ad ve soyad boş olamaz.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
