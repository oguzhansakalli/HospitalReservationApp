﻿using HospitalReservationSystem.Admin_Forms;
using HospitalReservationSystem.DAL;
using HospitalReservationSystem.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalReservationSystem
{
    public partial class AdminInterface : Form
    {
        private User _activeUser;
        public AdminInterface()
        {
            InitializeComponent();
        }

        private void AdminInterface_Load(object sender, EventArgs e)
        {
            timer1.Start();
            _activeUser = UsersHelper.ActiveUser;            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.lblTime.Text = DateTime.Now.ToString();
        }

        private void AdminInterface_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer1.Stop();
            Login l = new Login();
            l.Show();
        }

        private void tsbtnExit_Click(object sender, EventArgs e)
        {
            var isSuccessful = UsersHelper.Logout();
            if (isSuccessful)
            {                
                Close();
            }


        }

        private void tsbtnUsers_Click(object sender, EventArgs e)
        {
            UsersPanel up = new UsersPanel();
            up.Show();
        }

        private void tsbtnEmployees_Click(object sender, EventArgs e)
        {
            EmployeesPanel ep = new EmployeesPanel();
            ep.Show();
        }

        private void tsbtnDepartments_Click(object sender, EventArgs e)
        {
            DepartmentsPanel dp = new DepartmentsPanel();
            dp.Show();
        }

        private void tsbtnPatients_Click(object sender, EventArgs e)
        {

        }
    }
}
