﻿using HospitalReservationSystem.DAL;
using HospitalReservationSystem.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalReservationSystem
{
    public partial class AddEmployee : Form
    {
        public AddEmployee()
        {
            InitializeComponent();
        }

        private void AddEmployee_Load(object sender, EventArgs e)
        {
            LoadUsernames();
            LoadDepartments();
        }
        private void LoadUsernames()
        {
            var userlist = UsersHelper.GetActiveUsers();
            cmbUsers.ValueMember = "UserID";
            cmbUsers.DisplayMember = "Username";
            cmbUsers.DataSource = userlist;
        }
        private void LoadDepartments()
        {
            var deparmentlist = DepartmentsHelper.GetActiveDepartments();
            cmbDepartments.ValueMember = "DepartmentID";
            cmbDepartments.DisplayMember = "DName";
            cmbDepartments.DataSource = deparmentlist;
        }

        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtEmpName.Text) && !string.IsNullOrEmpty(txtEmpLname.Text))
            {
                Employee emp = new Employee();
                emp.UserID = Convert.ToInt32(cmbUsers.SelectedValue);
                emp.PName = txtEmpName.Text;
                emp.PLastname = txtEmpLname.Text;
                emp.DepartmentID = Convert.ToInt32(cmbDepartments.SelectedValue);
                emp.PStatus = true;
                var isSuccessful = EmployeesHelper.EmployeeCUD(emp, EntityState.Added);

                if (isSuccessful)
                {
                    MessageBox.Show("Yeni personel başarıyla sisteme eklendi.", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Personel ekleme başarısız.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            else
            {
                MessageBox.Show("Ad ve soyad boş olamaz.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
