﻿using HospitalReservationSystem.DAL;
using HospitalReservationSystem.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalReservationSystem.Admin_Forms
{
    public partial class DepartmentsPanel : Form
    {
        public DepartmentsPanel()
        {
            InitializeComponent();
        }

        private void AddDepartment_Click(object sender, EventArgs e)
        {
            groupBox3.Enabled = true;
        }

        private void DepartmentsPanel_Load(object sender, EventArgs e)
        {
            LoadDepartments(true);
            groupBox3.Enabled = false;
            groupBox4.Enabled = false;
        }
        private void LoadDepartments(bool status)
        {
            dgvDepartments.Rows.Clear();
            var dlist = DepartmentsHelper.GetActiveDepartments();
            foreach (var d in dlist)
            {
                if (d.DStatus == status)
                {
                    int satir = dgvDepartments.Rows.Add();
                    dgvDepartments.Rows[satir].Cells[0].Value = d.DepartmentID;
                    dgvDepartments.Rows[satir].Cells[1].Value = d.DName;
                }
            }
        }
        private void LoadDeletedDepartments(bool status)
        {
            dgvDepartments.Rows.Clear();
            var dlist = DepartmentsHelper.GetDeletedDepartments();
            foreach (var d in dlist)
            {
                if (d.DStatus == status)
                {
                    int satir = dgvDepartments.Rows.Add();
                    dgvDepartments.Rows[satir].Cells[0].Value = d.DepartmentID;
                    dgvDepartments.Rows[satir].Cells[1].Value = d.DName;
                }
            }
        }

        private void btnDeletedDepartments_Click(object sender, EventArgs e)
        {
            LoadDeletedDepartments(false);
        }

        private void btnUpdateDepartmentList_Click(object sender, EventArgs e)
        {
            LoadDepartments(true);
        }

        private void btnAddDepartment_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtDName.Text))
            {
                Department d = new Department();
                d.DName = txtDName.Text;
                d.DStatus = true;
                var isSuccessful = DepartmentsHelper.AddDepartment(d);
                if (isSuccessful)
                {
                    MessageBox.Show("Bölüm başarıyla eklendi.", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDepartments(true);
                    txtDName.Clear();
                    groupBox3.Enabled = false;
                }
                else
                {
                    MessageBox.Show("Bölüm ekleme hatalı.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Lütfen bölüm adı giriniz.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void UpdateDepartment_Click(object sender, EventArgs e)
        {
            groupBox4.Enabled = true;
            var row = dgvDepartments.CurrentRow.Index;
            var index = dgvDepartments.Rows[row].Cells[0].Value;
            var selectedDepartment = DepartmentsHelper.GetByID(Convert.ToInt32(index));
            txtNewDName.Text = selectedDepartment.DName;
        }

        private void btnUpdateDepartment_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNewDName.Text))
            {
                var row = dgvDepartments.CurrentRow.Index;
                var index = dgvDepartments.Rows[row].Cells[0].Value;
                var selectedDepartment = DepartmentsHelper.GetByID(Convert.ToInt32(index));
                var isSuccessful = DepartmentsHelper.ChangeDName(selectedDepartment, txtNewDName.Text);
                if (isSuccessful)
                {
                    MessageBox.Show("Bölüm adı başarıyla değiştirildi.", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDepartments(true);
                    txtNewDName.Clear();
                    groupBox4.Enabled = false;
                }
                else
                {
                    MessageBox.Show("Bölüm adı değiştirilirken hata meydana geldi.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Lütfen bölüm adı giriniz.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnDeleteDepartment_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Bölümü silmekte emin misiniz?(Bu işlem geri alınamaz.)", "UYARI", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dialogResult == DialogResult.Yes)
            {
                var row = dgvDepartments.CurrentRow.Index;
                var index = dgvDepartments.Rows[row].Cells[0].Value;
                var selectedDepartment = DepartmentsHelper.GetByID(Convert.ToInt32(index));
                var isSuccessful = DepartmentsHelper.DeleteDepartment(selectedDepartment);
                if (isSuccessful)
                {
                    MessageBox.Show("Bölüm başarıyla silindi.", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDepartments(true);
                }
                else
                {
                    MessageBox.Show("Bölüm silinirken hata meydana geldi.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
    }
}
