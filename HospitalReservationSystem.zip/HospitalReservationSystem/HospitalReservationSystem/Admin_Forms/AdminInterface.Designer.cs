﻿namespace HospitalReservationSystem
{
    partial class AdminInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminInterface));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbtnUsers = new System.Windows.Forms.ToolStripButton();
            this.tsbtnEmployees = new System.Windows.Forms.ToolStripButton();
            this.tsbtnDepartments = new System.Windows.Forms.ToolStripButton();
            this.tsbtnExit = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.sslUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTime = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.MistyRose;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(64, 64);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtnUsers,
            this.tsbtnEmployees,
            this.tsbtnDepartments,
            this.tsbtnExit});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(700, 86);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbtnUsers
            // 
            this.tsbtnUsers.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnUsers.Image")));
            this.tsbtnUsers.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnUsers.Name = "tsbtnUsers";
            this.tsbtnUsers.Padding = new System.Windows.Forms.Padding(0, 0, 100, 0);
            this.tsbtnUsers.Size = new System.Drawing.Size(169, 83);
            this.tsbtnUsers.Text = "Kullanıcılar";
            this.tsbtnUsers.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbtnUsers.Click += new System.EventHandler(this.tsbtnUsers_Click);
            // 
            // tsbtnEmployees
            // 
            this.tsbtnEmployees.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnEmployees.Image")));
            this.tsbtnEmployees.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnEmployees.Name = "tsbtnEmployees";
            this.tsbtnEmployees.Padding = new System.Windows.Forms.Padding(0, 0, 100, 0);
            this.tsbtnEmployees.Size = new System.Drawing.Size(169, 83);
            this.tsbtnEmployees.Text = "Personeller";
            this.tsbtnEmployees.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbtnEmployees.Click += new System.EventHandler(this.tsbtnEmployees_Click);
            // 
            // tsbtnDepartments
            // 
            this.tsbtnDepartments.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnDepartments.Image")));
            this.tsbtnDepartments.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnDepartments.Name = "tsbtnDepartments";
            this.tsbtnDepartments.Padding = new System.Windows.Forms.Padding(0, 0, 100, 0);
            this.tsbtnDepartments.Size = new System.Drawing.Size(168, 83);
            this.tsbtnDepartments.Text = "Bölümler";
            this.tsbtnDepartments.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbtnDepartments.Click += new System.EventHandler(this.tsbtnDepartments_Click);
            // 
            // tsbtnExit
            // 
            this.tsbtnExit.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnExit.Image")));
            this.tsbtnExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnExit.Name = "tsbtnExit";
            this.tsbtnExit.Padding = new System.Windows.Forms.Padding(0, 0, 100, 0);
            this.tsbtnExit.Size = new System.Drawing.Size(168, 83);
            this.tsbtnExit.Text = "Çıkış Yap";
            this.tsbtnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbtnExit.Click += new System.EventHandler(this.tsbtnExit_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.MistyRose;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.sslUser});
            this.statusStrip1.Location = new System.Drawing.Point(0, 244);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(700, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.BackColor = System.Drawing.Color.MistyRose;
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(51, 17);
            this.toolStripStatusLabel1.Text = "Status : ";
            // 
            // sslUser
            // 
            this.sslUser.BackColor = System.Drawing.Color.MistyRose;
            this.sslUser.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.sslUser.ForeColor = System.Drawing.SystemColors.Highlight;
            this.sslUser.Name = "sslUser";
            this.sslUser.Size = new System.Drawing.Size(43, 17);
            this.sslUser.Text = "Admin";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.BackColor = System.Drawing.Color.DarkRed;
            this.lblTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTime.ForeColor = System.Drawing.SystemColors.Info;
            this.lblTime.Location = new System.Drawing.Point(49, 126);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(78, 25);
            this.lblTime.TabIndex = 2;
            this.lblTime.Text = "Zaman";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // AdminInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkRed;
            this.ClientSize = new System.Drawing.Size(701, 266);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "AdminInterface";
            this.Padding = new System.Windows.Forms.Padding(0, 0, 1, 0);
            this.Text = "Hastane Yönetim Paneli";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AdminInterface_FormClosing);
            this.Load += new System.EventHandler(this.AdminInterface_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbtnUsers;
        private System.Windows.Forms.ToolStripButton tsbtnEmployees;
        private System.Windows.Forms.ToolStripButton tsbtnDepartments;
        private System.Windows.Forms.ToolStripButton tsbtnExit;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel sslUser;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Timer timer1;
    }
}