﻿using HospitalReservationSystem.DAL;
using HospitalReservationSystem.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalReservationSystem
{
    public partial class UsersPanel : Form
    {
        public UsersPanel()
        {
            InitializeComponent();
        }
        private void UsersPanel_Load(object sender, EventArgs e)
        {
            LoadUsers(true);
        }
        private void btnAddUser_Click(object sender, EventArgs e)
        {
            AddUserPanel aup = new AddUserPanel();
            aup.Show();
        }

        private void btnUpdateUserList_Click(object sender, EventArgs e)
        {
            LoadUsers(true);
        }
        private void LoadUsers(bool status)
        {
            dataGridView1.Rows.Clear();
            var userlist = UsersHelper.GetUsers();
            foreach (var user in userlist)
            {
                if (user.UStatus == status)
                {
                    int satir = dataGridView1.Rows.Add();
                    dataGridView1.Rows[satir].Cells[0].Value = user.UserID;
                    dataGridView1.Rows[satir].Cells[1].Value = user.Username;
                    dataGridView1.Rows[satir].Cells[2].Value = user.Password;
                    if (user.UType == 0)
                    {
                        dataGridView1.Rows[satir].Cells[3].Value = "Admin";
                    }
                    else if (user.UType == 1)
                    {
                        dataGridView1.Rows[satir].Cells[3].Value = "Doktor";
                    }
                    else if (user.UType == 2)
                    {
                        dataGridView1.Rows[satir].Cells[3].Value = "Resepsiyonist";
                    }
                }
            }
        }

        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Kullanıcıyı silmekte emin misiniz?(Bu işlem geri alınamaz.)", "UYARI", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dialogResult == DialogResult.Yes)
            {
                User selectedUser = new User();

                var row = dataGridView1.CurrentRow.Index;
                selectedUser.UserID = Convert.ToInt32(dataGridView1.Rows[row].Cells[0].Value);
                selectedUser.Username = dataGridView1.Rows[row].Cells[1].Value.ToString();
                selectedUser.Password = dataGridView1.Rows[row].Cells[2].Value.ToString();
                if (dataGridView1.Rows[row].Cells[3].Value.ToString() == "Admin")
                {
                    selectedUser.UType = 0;
                }
                else if (dataGridView1.Rows[row].Cells[3].Value.ToString() == "Doktor")
                {
                    selectedUser.UType = 1;
                }
                else if (dataGridView1.Rows[row].Cells[3].Value.ToString() == "Resepsiyonist")
                {
                    selectedUser.UType = 2;
                }
                selectedUser.UStatus = false;

                var isSuccessful = UsersHelper.UserCUD(selectedUser, System.Data.Entity.EntityState.Modified);
                if (isSuccessful)
                {
                    MessageBox.Show("Kullanıcı başarıyla silindi.", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadUsers(true);
                }
                else
                {
                    MessageBox.Show("Kullanıcı silme başarısız.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnDeletedUsers_Click(object sender, EventArgs e)
        {
            LoadUsers(false);
        }
    }
}
