﻿namespace HospitalReservationSystem.Admin_Forms
{
    partial class DepartmentsPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDeletedDepartments = new System.Windows.Forms.Button();
            this.btnUpdateDepartmentList = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgvDepartments = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnDeleteDepartment = new System.Windows.Forms.Button();
            this.UpdateDepartment = new System.Windows.Forms.Button();
            this.AddDepartment = new System.Windows.Forms.Button();
            this.txtDName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnAddDepartment = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnUpdateDepartment = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNewDName = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDepartments)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDeletedDepartments
            // 
            this.btnDeletedDepartments.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnDeletedDepartments.Location = new System.Drawing.Point(599, 21);
            this.btnDeletedDepartments.Name = "btnDeletedDepartments";
            this.btnDeletedDepartments.Size = new System.Drawing.Size(184, 34);
            this.btnDeletedDepartments.TabIndex = 12;
            this.btnDeletedDepartments.Text = "Silinen Bölümleri  Gör";
            this.btnDeletedDepartments.UseVisualStyleBackColor = true;
            this.btnDeletedDepartments.Click += new System.EventHandler(this.btnDeletedDepartments_Click);
            // 
            // btnUpdateDepartmentList
            // 
            this.btnUpdateDepartmentList.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnUpdateDepartmentList.Location = new System.Drawing.Point(160, 21);
            this.btnUpdateDepartmentList.Name = "btnUpdateDepartmentList";
            this.btnUpdateDepartmentList.Size = new System.Drawing.Size(184, 34);
            this.btnUpdateDepartmentList.TabIndex = 11;
            this.btnUpdateDepartmentList.Text = "Güncel Bölümlerin Listesi";
            this.btnUpdateDepartmentList.UseVisualStyleBackColor = true;
            this.btnUpdateDepartmentList.Click += new System.EventHandler(this.btnUpdateDepartmentList_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.groupBox1.Controls.Add(this.dgvDepartments);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.Location = new System.Drawing.Point(26, 61);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(440, 369);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bölümler";
            // 
            // dgvDepartments
            // 
            this.dgvDepartments.AllowUserToAddRows = false;
            this.dgvDepartments.AllowUserToDeleteRows = false;
            this.dgvDepartments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDepartments.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column5});
            this.dgvDepartments.Location = new System.Drawing.Point(6, 23);
            this.dgvDepartments.Name = "dgvDepartments";
            this.dgvDepartments.ReadOnly = true;
            this.dgvDepartments.Size = new System.Drawing.Size(424, 340);
            this.dgvDepartments.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "DepartmentID";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 130;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Department Name";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 250;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnDeleteDepartment);
            this.groupBox2.Controls.Add(this.UpdateDepartment);
            this.groupBox2.Controls.Add(this.AddDepartment);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox2.Location = new System.Drawing.Point(485, 61);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(413, 100);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Liste İşlemleri";
            // 
            // btnDeleteDepartment
            // 
            this.btnDeleteDepartment.Location = new System.Drawing.Point(294, 40);
            this.btnDeleteDepartment.Name = "btnDeleteDepartment";
            this.btnDeleteDepartment.Size = new System.Drawing.Size(99, 41);
            this.btnDeleteDepartment.TabIndex = 2;
            this.btnDeleteDepartment.Text = "Bölümü Sil";
            this.btnDeleteDepartment.UseVisualStyleBackColor = true;
            this.btnDeleteDepartment.Click += new System.EventHandler(this.btnDeleteDepartment_Click);
            // 
            // UpdateDepartment
            // 
            this.UpdateDepartment.Location = new System.Drawing.Point(168, 40);
            this.UpdateDepartment.Name = "UpdateDepartment";
            this.UpdateDepartment.Size = new System.Drawing.Size(99, 41);
            this.UpdateDepartment.TabIndex = 1;
            this.UpdateDepartment.Text = "Güncelle";
            this.UpdateDepartment.UseVisualStyleBackColor = true;
            this.UpdateDepartment.Click += new System.EventHandler(this.UpdateDepartment_Click);
            // 
            // AddDepartment
            // 
            this.AddDepartment.Location = new System.Drawing.Point(33, 40);
            this.AddDepartment.Name = "AddDepartment";
            this.AddDepartment.Size = new System.Drawing.Size(104, 41);
            this.AddDepartment.TabIndex = 0;
            this.AddDepartment.Text = "Bölüm Ekle";
            this.AddDepartment.UseVisualStyleBackColor = true;
            this.AddDepartment.Click += new System.EventHandler(this.AddDepartment_Click);
            // 
            // txtDName
            // 
            this.txtDName.Location = new System.Drawing.Point(114, 29);
            this.txtDName.Name = "txtDName";
            this.txtDName.Size = new System.Drawing.Size(279, 24);
            this.txtDName.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(6, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 18);
            this.label1.TabIndex = 15;
            this.label1.Text = "Bölümün Adı";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnAddDepartment);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.txtDName);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox3.Location = new System.Drawing.Point(485, 176);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(413, 116);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Ekleme İşlemi";
            // 
            // btnAddDepartment
            // 
            this.btnAddDepartment.Location = new System.Drawing.Point(210, 70);
            this.btnAddDepartment.Name = "btnAddDepartment";
            this.btnAddDepartment.Size = new System.Drawing.Size(183, 31);
            this.btnAddDepartment.TabIndex = 16;
            this.btnAddDepartment.Text = "Kaydı Bitir";
            this.btnAddDepartment.UseVisualStyleBackColor = true;
            this.btnAddDepartment.Click += new System.EventHandler(this.btnAddDepartment_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnUpdateDepartment);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.txtNewDName);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox4.Location = new System.Drawing.Point(485, 311);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(413, 119);
            this.groupBox4.TabIndex = 17;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Güncelleme İşlemi";
            // 
            // btnUpdateDepartment
            // 
            this.btnUpdateDepartment.Location = new System.Drawing.Point(210, 82);
            this.btnUpdateDepartment.Name = "btnUpdateDepartment";
            this.btnUpdateDepartment.Size = new System.Drawing.Size(183, 31);
            this.btnUpdateDepartment.TabIndex = 16;
            this.btnUpdateDepartment.Text = "Kaydı Güncelle";
            this.btnUpdateDepartment.UseVisualStyleBackColor = true;
            this.btnUpdateDepartment.Click += new System.EventHandler(this.btnUpdateDepartment_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(6, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 18);
            this.label2.TabIndex = 15;
            this.label2.Text = "Bölümün Adı";
            // 
            // txtNewDName
            // 
            this.txtNewDName.Location = new System.Drawing.Point(114, 29);
            this.txtNewDName.Name = "txtNewDName";
            this.txtNewDName.Size = new System.Drawing.Size(279, 24);
            this.txtNewDName.TabIndex = 14;
            // 
            // DepartmentsPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(921, 444);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnDeletedDepartments);
            this.Controls.Add(this.btnUpdateDepartmentList);
            this.Controls.Add(this.groupBox1);
            this.Name = "DepartmentsPanel";
            this.Text = "Bölüm Yönetim Paneli";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.DepartmentsPanel_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDepartments)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnDeletedDepartments;
        private System.Windows.Forms.Button btnUpdateDepartmentList;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dgvDepartments;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnDeleteDepartment;
        private System.Windows.Forms.Button UpdateDepartment;
        private System.Windows.Forms.Button AddDepartment;
        private System.Windows.Forms.TextBox txtDName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnAddDepartment;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnUpdateDepartment;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNewDName;
    }
}