﻿using HospitalReservationSystem.DAL;
using HospitalReservationSystem.Receptionist_Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalReservationSystem
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            cmbUType.SelectedIndex = -1;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            int UType = cmbUType.SelectedIndex;
            
            if (cmbUType.SelectedIndex != -1)
            {
                if (UType==1)
                {
                    UType += 1;
                }
                var saveModal = UsersHelper.Login(username, password, UType);

                if (saveModal.isSuccessful)
                {
                    Hide();
                    if (UType == 0)
                    {
                        MessageBox.Show(saveModal.message, "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        AdminInterface ai = new AdminInterface();
                        ai.Show(); 
                    }                    
                    else if (UType == 2)
                    {
                        MessageBox.Show(saveModal.message, "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ReceptionistInterface ri = new ReceptionistInterface();
                        ri.Show();
                    }

                }
                else
                {
                    MessageBox.Show(saveModal.message, "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Lütfen bir kullanıcı tipi seçin.", "UYARI", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void OnlyLetterOrDigit(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetterOrDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void NoSpace(object sender, KeyPressEventArgs e)
        {
            if (char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        
    }
}
