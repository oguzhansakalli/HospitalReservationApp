﻿using HospitalReservationSystem.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalReservationSystem.Modals
{
    class EmployeeModal
    {
        public int PersonnelID { get; set; }
        public int UserID { get; set; }
        public int DepartmentID { get; set; }
        public string PName { get; set; }
        public string PLastname { get; set; }
        public bool PStatus { get; set; }
        
        public ICollection<Appointment> Appointments { get; set; }
        public Department Department = new Department();
        public User User { get; set; }
    }
}
