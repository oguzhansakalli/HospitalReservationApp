﻿using HospitalReservationSystem.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalReservationSystem.Modals
{
    class AppointmentModal
    {
        public int AppointmentID { get; set; }
        public int PatientID { get; set; }
        public int PersonnelID { get; set; }
        public int SessionID { get; set; }
        public System.DateTime Date { get; set; }
        public bool AStatus { get; set; }

        public Session Session = new Session();       
       
        public EmployeeModal EmployeeModal = new EmployeeModal();
        public PatientInformation PatientInformation = new PatientInformation();
    }
}
